import dotenv from "dotenv";
dotenv.config();

import express from "express";
import path from "path";
import fs from "fs";
import readline from "readline";
import multer from "multer";
import { createServer as createViteServer } from "vite";
import { createClient } from "@supabase/supabase-js";

const app = express();
const PORT = 3000;

app.use(express.json());

const debugLogPath = path.join(process.cwd(), "tmp", "server_debug.log");
function writeDebugLog(message: string) {
  try {
    const timestamp = new Date().toISOString();
    fs.appendFileSync(debugLogPath, `[${timestamp}] ${message}\n`);
    console.log(`[DebugLog] ${message}`);
  } catch (err) {
    console.error("Failed to write to debug log:", err);
  }
}

// Ensure clean file on startup
try {
  if (!fs.existsSync(path.dirname(debugLogPath))) {
    fs.mkdirSync(path.dirname(debugLogPath), { recursive: true });
  }
  fs.writeFileSync(debugLogPath, `--- SERVER STARTUP --- NODE_ENV=${process.env.NODE_ENV}\n`);
} catch (e) {}

app.use((req, res, next) => {
  writeDebugLog(`INCOMING REQUEST: ${req.method} ${req.url} - Headers: ${JSON.stringify(req.headers)}`);
  
  // Intercept json response
  const oldJson = res.json;
  res.json = function(data) {
    writeDebugLog(`RESPONSE JSON: ${res.statusCode} for ${req.method} ${req.url}`);
    return oldJson.call(this, data);
  };
  
  // Intercept send response
  const oldSend = res.send;
  res.send = function(data) {
    writeDebugLog(`RESPONSE SEND: ${res.statusCode} for ${req.method} ${req.url} - Length: ${data ? data.length : 0}`);
    return oldSend.call(this, data);
  };

  next();
});

// Set up temporary storage for incoming multer multi-part uploads
const uploadDir = path.join(process.cwd(), "tmp");
const multerTempDir = path.join(uploadDir, "multer_temp");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}
if (!fs.existsSync(multerTempDir)) {
  fs.mkdirSync(multerTempDir, { recursive: true });
}

const uploader = multer({ dest: multerTempDir });

// Background Migration Status Storage
interface MigrationStatus {
  status: "pending" | "merging" | "inserting" | "completed" | "failed";
  progress: number;
  totalRows: number;
  insertedRows: number;
  invalidLinesCount: number;
  invalidLines?: { lineNum: number; content: string }[];
  errorMessage?: string;
  tableName: string;
  fileName: string;
  currentBatchRange?: string;
  failedBatchesCount?: number;
  failedBatches?: { range: string; error: string }[];
}

const statusStore: Record<string, MigrationStatus> = {};

// Custom CSV/TXT Line Parser with character quote escaping support
function parseLineWithQuotes(line: string, delimiter: string): string[] {
  const cleanLine = line.replace(/[\r\n]+/g, "").trim();
  if (!cleanLine) {
    return [];
  }

  if (!cleanLine.includes('"')) {
    return cleanLine.split(delimiter);
  }

  const result: string[] = [];
  let current = "";
  let inQuotes = false;
  
  for (let i = 0; i < cleanLine.length; i++) {
    const char = cleanLine[i];
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === delimiter && !inQuotes) {
      result.push(current);
      current = "";
    } else {
      current += char;
    }
  }
  result.push(current);
  return result;
}

// Merge file chunks synchronously/asynchronously and stream upload data to Supabase in the background
async function processMigrationInBackground(config: {
  fileId: string;
  fileName: string;
  tableName: string;
  delimiter: string;
  skipHeader: boolean;
  totalChunks: number;
  supabaseUrl?: string;
  supabaseKey?: string;
}) {
  const { fileId, fileName, tableName, delimiter, skipHeader, totalChunks, supabaseUrl, supabaseKey } = config;

  const activeUrl = supabaseUrl || process.env.REACT_APP_SUPABASE_URL || "https://bddexsjlwhwxhivcyfrk.supabase.co";
  const activeKey = supabaseKey || process.env.REACT_APP_SUPABASE_PUBLISHABLE_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJkZGV4c2psd2h3eGhpdmN5ZnJrIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc4MDg0NDcwNiwiZXhwIjoyMDk2NDIwNzA2fQ.BfTFPxvapxxSqU7HRu5GGkjPoFZcQZSzqSUK9d1w-HQ";

  if (!activeUrl || !activeKey) {
    throw new Error("Supabase URL and Key are required for connecting database.");
  }

  const localSupabase = createClient(activeUrl, activeKey);
  const chunkDir = path.join(process.cwd(), "tmp", "uploads", fileId);
  const reconstructedPath = path.join(chunkDir, `reconstructed_${fileName}`);

  try {
    // 1. Update status to 'merging'
    statusStore[fileId] = {
      status: "merging",
      progress: 5,
      totalRows: 0,
      insertedRows: 0,
      invalidLinesCount: 0,
      invalidLines: [],
      tableName,
      fileName,
      currentBatchRange: "Iniciando...",
      failedBatchesCount: 0,
      failedBatches: [],
    };

    console.log(`[Migration ${fileId}] Starting to merge ${totalChunks} chunks...`);

    // 2. Perform file merger
    const writeStream = fs.createWriteStream(reconstructedPath);

    for (let i = 0; i < totalChunks; i++) {
      const chunkPath = path.join(chunkDir, `chunk_${i}`);
      if (!fs.existsSync(chunkPath)) {
        throw new Error(`Chunk file index ${i} was not found on the server.`);
      }

      await new Promise<void>((resolve, reject) => {
        const readStream = fs.createReadStream(chunkPath);
        readStream.pipe(writeStream, { end: false });
        readStream.on("end", () => resolve());
        readStream.on("error", (err) => reject(err));
      });
    }
    
    writeStream.end();
    
    // Wait for the final lock on the reconstructed file
    await new Promise<void>((resolve) => {
      writeStream.on("finish", () => resolve());
    });

    console.log(`[Migration ${fileId}] Merge completed. Reconstructed file path: ${reconstructedPath}`);

    // Verify structural file stats
    const fileStats = fs.statSync(reconstructedPath);
    const totalBytes = fileStats.size;

    statusStore[fileId].status = "inserting";
    statusStore[fileId].progress = 10;

    // 3. Setup File Streams and Line Processing
    const fileStream = fs.createReadStream(reconstructedPath);
    const rl = readline.createInterface({
      input: fileStream,
      crlfDelay: Infinity,
    });

    let lineNumber = 0;
    let bytesRead = 0;
    const BATCH_SIZE = 100;
    let batch: any[] = [];
    let batchLineNumbers: number[] = [];
    
    let activeDelimiter = delimiter;

    // Track stream progress accurate in bytes
    fileStream.on("data", (chunk) => {
      bytesRead += chunk.length;
      if (totalBytes > 0) {
        // Map 10% to 95% range for insert progress; remaining is validation and final trigger
        const percent = Math.min(10 + Math.floor((bytesRead / totalBytes) * 85), 95);
        if (statusStore[fileId] && statusStore[fileId].status === "inserting") {
          statusStore[fileId].progress = percent;
        }
      }
    });

    for await (const line of rl) {
      lineNumber++;
      if (!line || !line.trim()) {
        continue;
      }

      // Analysis on the first active line
      if (lineNumber === 1 || (lineNumber === 2 && skipHeader)) {
        // Auto Delimiter Detection: Support standard separator counts
        const possibleDelimiters = [",", ";", "|", "\t"];
        let bestDelimiter = delimiter;
        let maxCount = line.split(delimiter).length - 1;

        for (const d of possibleDelimiters) {
          const count = line.split(d).length - 1;
          // We expect 5 delimiters for 6 components
          if (count > maxCount && count >= 5) {
            maxCount = count;
            bestDelimiter = d;
          }
        }

        if (bestDelimiter !== activeDelimiter) {
          console.log(`[Auto-Detect] Delimiter switched from '${activeDelimiter}' to '${bestDelimiter}'`);
          activeDelimiter = bestDelimiter;
        }

        // Trim parsed items to inspect numerical status
        const firstLineCols = parseLineWithQuotes(line, activeDelimiter).map(c => c.trim());
        const isFirstColNumeric = firstLineCols[0] && /^\d+$/.test(firstLineCols[0]);

        if (skipHeader && lineNumber === 1) {
          if (isFirstColNumeric) {
            console.log(`[Auto-Header Override] Solicitado ignorar cabecera, pero la primera fila parece contener datos numéricos ('${firstLineCols[0]}'). Se procesará la fila para evitar pérdida de registros.`);
          } else {
            console.log(`[Migration] Cabecera ignorada exitosamente.`);
            continue;
          }
        }
      }

      const columns = parseLineWithQuotes(line, activeDelimiter).map(c => c.trim());

      // Accept >= 6 columns. Trailing commas or tabs may increase count, which we handle safely.
      if (columns.length < 6) {
        statusStore[fileId].invalidLinesCount++;
        if (!statusStore[fileId].invalidLines) {
          statusStore[fileId].invalidLines = [];
        }
        if (statusStore[fileId].invalidLines.length < 200) {
          statusStore[fileId].invalidLines.push({
            lineNum: lineNumber,
            content: line
          });
        }
        continue;
      }

      const row = {
        id_usuario: columns[0] || null,
        tipo_documento: columns[1] || null,
        numero_documento: columns[2] || null,
        fecha_inicio: columns[3] || null,
        fecha_fin: columns[4] || null,
        codigo: columns[5] || null,
      };

      batch.push(row);
      batchLineNumbers.push(lineNumber);
      statusStore[fileId].totalRows++;

      if (batch.length >= BATCH_SIZE) {
        const batchToInsert = [...batch];
        const lineStart = batchLineNumbers[0];
        const lineEnd = batchLineNumbers[batchLineNumbers.length - 1];
        const rangeText = `Líneas ${lineStart} - ${lineEnd}`;
        
        statusStore[fileId].currentBatchRange = rangeText;
        console.log(`[Migration ${fileId}] Inserting range: ${rangeText}`);

        batch = []; // clear quickly
        batchLineNumbers = [];

        try {
          const { error } = await localSupabase.from(tableName).insert(batchToInsert);
          if (error) {
            throw new Error(`[Supabase Error] ${error.message} (Detalle: ${error.details || ""})`);
          }
          statusStore[fileId].insertedRows += batchToInsert.length;
        } catch (e: any) {
          console.error(`[MigrationError ${fileId}] Error in ${rangeText}:`, e);
          statusStore[fileId].failedBatchesCount = (statusStore[fileId].failedBatchesCount || 0) + 1;
          if (!statusStore[fileId].failedBatches) {
            statusStore[fileId].failedBatches = [];
          }
          statusStore[fileId].failedBatches.push({
            range: rangeText,
            error: e?.message || String(e),
          });
        }
      }
    }

    // Flush remaining lines in final batch
    if (batch.length > 0) {
      const batchToInsert = [...batch];
      const lineStart = batchLineNumbers[0];
      const lineEnd = batchLineNumbers[batchLineNumbers.length - 1];
      const rangeText = `Líneas ${lineStart} - ${lineEnd}`;
      
      statusStore[fileId].currentBatchRange = rangeText;
      console.log(`[Migration ${fileId}] Inserting final range: ${rangeText}`);

      try {
        const { error } = await localSupabase.from(tableName).insert(batchToInsert);
        if (error) {
          throw new Error(`[Supabase Error] ${error.message} (Detalle: ${error.details || ""})`);
        }
        statusStore[fileId].insertedRows += batchToInsert.length;
      } catch (e: any) {
        console.error(`[MigrationError ${fileId}] Error in final ${rangeText}:`, e);
        statusStore[fileId].failedBatchesCount = (statusStore[fileId].failedBatchesCount || 0) + 1;
        if (!statusStore[fileId].failedBatches) {
          statusStore[fileId].failedBatches = [];
        }
        statusStore[fileId].failedBatches.push({
          range: rangeText,
          error: e?.message || String(e),
        });
      }
    }

    // Done! Successful completion
    console.log(`[Migration ${fileId}] Successfully processed all lines! Total: ${statusStore[fileId].totalRows}`);
    statusStore[fileId].status = "completed";
    statusStore[fileId].progress = 100;

    // Simple delay self-cleanup of temporary chunk directory
    setTimeout(() => {
      try {
        if (fs.existsSync(chunkDir)) {
          fs.rmSync(chunkDir, { recursive: true, force: true });
          console.log(`[Migration ${fileId}] Temp workspace files cleaned up.`);
        }
      } catch (err) {
        console.error("Failed to cleanup files:", err);
      }
    }, 10000);

  } catch (err: any) {
    console.error(`[Migration Error ${fileId}]`, err);
    statusStore[fileId] = {
      ...statusStore[fileId],
      status: "failed",
      errorMessage: err?.message || String(err),
    };
  }
}

// ---------------------- ENDPOINTS ----------------------

// Endpoint for receiving chunks
app.post("/api/upload-chunk", uploader.single("chunk"), async (req, res) => {
  try {
    const chunkFile = req.file;
    if (!chunkFile) {
      return res.status(400).json({ error: "No se proporcionó ningún fragmento de archivo." });
    }

    const fileId = req.body.fileId;
    const chunkIndex = parseInt(req.body.chunkIndex, 10);
    const totalChunks = parseInt(req.body.totalChunks, 10);
    const fileName = req.body.fileName;
    const tableName = req.body.tableName;
    const delimiter = req.body.delimiter || ",";
    const skipHeader = req.body.skipHeader === "true";
    const supabaseUrl = req.body.supabaseUrl;
    const supabaseKey = req.body.supabaseKey;

    if (!fileId || isNaN(chunkIndex) || isNaN(totalChunks) || !tableName) {
      // Cleanup multer upload file immediately
      if (fs.existsSync(chunkFile.path)) fs.unlinkSync(chunkFile.path);
      return res.status(400).json({ error: "Faltan parámetros de envío obligatorios." });
    }

    // Create chunks directory structure for the specific session ID
    const chunkDir = path.join(process.cwd(), "tmp", "uploads", fileId);
    if (!fs.existsSync(chunkDir)) {
      fs.mkdirSync(chunkDir, { recursive: true });
    }

    // Move uploaded multer temp file to designated chunk file index destination
    const destPath = path.join(chunkDir, `chunk_${chunkIndex}`);
    fs.renameSync(chunkFile.path, destPath);

    // Initial status store representation
    if (!statusStore[fileId]) {
      statusStore[fileId] = {
        status: "pending",
        progress: Math.floor(((chunkIndex + 1) / totalChunks) * 100),
        totalRows: 0,
        insertedRows: 0,
        invalidLinesCount: 0,
        invalidLines: [],
        tableName,
        fileName,
        currentBatchRange: "Subiendo Archivos...",
        failedBatchesCount: 0,
        failedBatches: [],
      };
    } else if (statusStore[fileId].status === "pending") {
      // Approximate physical chunk upload progress
      statusStore[fileId].progress = Math.floor(((chunkIndex + 1) / totalChunks) * 100);
    }

    // Check if we have received all chunks to kick off background reconstruction and loading
    const files = fs.readdirSync(chunkDir);
    const uploadedChunksCollected = files.filter(f => f.startsWith("chunk_")).length;

    if (uploadedChunksCollected === totalChunks) {
      // Run background parser thread so HTTP response returns instantly and avoids connection timeouts!
      processMigrationInBackground({
        fileId,
        fileName,
        tableName,
        delimiter,
        skipHeader,
        totalChunks,
        supabaseUrl,
        supabaseKey,
      });
      
      return res.json({
        success: true,
        message: "Todos los chunks recibidos. Iniciando procesamiento en segundo plano.",
        status: "processing",
      });
    }

    return res.json({
      success: true,
      message: `Fragmento ${chunkIndex + 1} de ${totalChunks} recibido exitosamente.`,
      status: "uploading",
      progress: Math.min(99, Math.floor(((chunkIndex + 1) / totalChunks) * 100)),
    });

  } catch (err: any) {
    console.error("Error upload-chunk endpoint:", err);
    return res.status(500).json({ error: err?.message || "Ocurrió un error en el servidor." });
  }
});

// GET Endpoint for checking live status of an asynchronous upload session
app.get("/api/migration-status/:fileId", (req, res) => {
  const { fileId } = req.params;
  const status = statusStore[fileId];
  if (!status) {
    return res.status(404).json({ error: "No se encontró ningún proceso con ese identificador." });
  }
  return res.json(status);
});

// Endpoint to cancel / clear previous files of a session
app.post("/api/cancel-migration/:fileId", (req, res) => {
  const { fileId } = req.params;
  try {
    delete statusStore[fileId];
    const chunkDir = path.join(process.cwd(), "tmp", "uploads", fileId);
    if (fs.existsSync(chunkDir)) {
      fs.rmSync(chunkDir, { recursive: true, force: true });
    }
    return res.json({ success: true, message: "Operación cancelada y recursos limpiados con éxito." });
  } catch (err) {
    return res.json({ success: false, error: String(err) });
  }
});

// 404 handler for API routes to prevent falling through to Vite or static files
app.all("/api/*", (req, res) => {
  writeDebugLog(`API 404 NOT FOUND: ${req.method} ${req.url}`);
  res.status(404).json({
    error: `La ruta de la API ${req.method} ${req.url} no fue encontrada en este servidor.`
  });
});

// Global error handler for Express
app.use((err: any, req: any, res: any, next: any) => {
  writeDebugLog(`GLOBAL ERROR CAUGHT: ${err?.message || err}`);
  if (err?.stack) {
    writeDebugLog(`ERROR STACK: ${err.stack}`);
  }
  if (res.headersSent) {
    return next(err);
  }
  res.status(err?.status || 500).json({
    error: `Error interno del servidor: ${err?.message || String(err)}`
  });
});

// Configure Vite or Static Assets Hosting
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Server] Royal Blue Migrator server running on http://localhost:${PORT}`);
  });
}

startServer();
