import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Upload,
  Database,
  FileSpreadsheet,
  Copy,
  Check,
  Loader2,
  Play,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  HelpCircle,
  FileText,
  ChevronRight,
  DatabaseZap,
  Info,
  Zap
} from "lucide-react";

function checkIsAnonKey(key: string): boolean {
  try {
    const parts = key.split(".");
    if (parts.length === 3) {
      const base64Url = parts[1];
      const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
      const jsonPayload = decodeURIComponent(
        atob(base64)
          .split("")
          .map((c) => "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2))
          .join("")
      );
      const payload = JSON.parse(jsonPayload);
      return payload.role === "anon";
    }
  } catch (e) {
    // ignore
  }
  return false;
}

interface MigrationStatus {
  status: "pending" | "merging" | "inserting" | "completed" | "failed";
  progress: number;
  totalRows: number;
  insertedRows: number;
  invalidLinesCount: number;
  invalidLines?: { lineNum: number; content: string }[];
  errorMessage?: string;
  tableName: string;
  fileName: string;
  currentBatchRange?: string;
  failedBatchesCount?: number;
  failedBatches?: { range: string; error: string }[];
}

export default function App() {
  const [file, setFile] = useState<File | null>(null);
  const [tableName, setTableName] = useState<string>("registros_masivos");
  const [delimiter, setDelimiter] = useState<string>(",");
  const [skipHeader, setSkipHeader] = useState<boolean>(true);
  const [uploading, setUploading] = useState<boolean>(false);
  const [clientProgress, setClientProgress] = useState<number>(0);
  const [currentChunkIndex, setCurrentChunkIndex] = useState<number>(0);
  const [totalChunksIndex, setTotalChunksIndex] = useState<number>(0);
  const [fileId, setFileId] = useState<string>("");
  const [statusPollingActive, setStatusPollingActive] = useState<boolean>(false);
  
  // Custom Dynamic Supabase Credentials
  const [supabaseUrl, setSupabaseUrl] = useState<string>(() => {
    return localStorage.getItem("supabase_url") || "https://bddexsjlwhwxhivcyfrk.supabase.co";
  });
  const [supabaseKey, setSupabaseKey] = useState<string>(() => {
    const cached = localStorage.getItem("supabase_key");
    if (cached && cached !== "sb_publishable_TcJxaDTzX6egTfF0n84Cgw_mH6fnjSh") {
      return cached;
    }
    return "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJkZGV4c2psd2h3eGhpdmN5ZnJrIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc4MDg0NDcwNiwiZXhwIjoyMDk2NDIwNzA2fQ.BfTFPxvapxxSqU7HRu5GGkjPoFZcQZSzqSUK9d1w-HQ";
  });
  const [showDbSettings, setShowDbSettings] = useState<boolean>(false);

  // Real-time backend status retrieved during polling
  const [backendStatus, setBackendStatus] = useState<MigrationStatus | null>(null);
  const [showInvalidList, setShowInvalidList] = useState<boolean>(false);
  const [showFailedBatchesList, setShowFailedBatchesList] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);
  const [dragActive, setDragActive] = useState<boolean>(false);

  useEffect(() => {
    localStorage.setItem("supabase_url", supabaseUrl);
  }, [supabaseUrl]);

  useEffect(() => {
    localStorage.setItem("supabase_key", supabaseKey);
  }, [supabaseKey]);

  // Hook to automatically expand DB Settings when Supabase key errors are detected
  useEffect(() => {
    if (error && (
      error.toLowerCase().includes("api key") || 
      error.toLowerCase().includes("key") || 
      error.toLowerCase().includes("supabase error") ||
      error.toLowerCase().includes("credentials") ||
      error.toLowerCase().includes("api_key")
    )) {
      setShowDbSettings(true);
    }
  }, [error]);

  // Restore migration state on mount/reconnect (e.g. if the dev server restarts or websocket reconnects)
  useEffect(() => {
    const savedFileId = localStorage.getItem("migration_file_id");
    const savedTableName = localStorage.getItem("migration_table_name");
    const savedFileName = localStorage.getItem("migration_file_name");
    
    if (savedFileId) {
      setFileId(savedFileId);
      if (savedTableName) setTableName(savedTableName);
      if (savedFileName) {
        setFile(new File([], savedFileName, { type: "text/plain" }));
      }
      
      // Attempt to immediately fetch current status from server to resume polling if in progress
      fetch(`/api/migration-status/${savedFileId}`)
        .then((res) => {
          if (res.ok) {
            return res.json();
          }
          throw new Error("Nueva conexión establecida con el servidor...");
        })
        .then((data) => {
          setBackendStatus(data);
          if (data.status !== "completed" && data.status !== "failed") {
            setUploading(true);
            setStatusPollingActive(true);
            console.log(`[Reconexión Auto] Se reanudó el seguimiento de migración para ID: ${savedFileId}`);
          }
        })
        .catch((err) => {
          console.warn("[Reconexión Auto] El servidor no tiene registro activo de esta sesión:", err);
        });
    }
  }, []);

  // Hidden file input ref
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-generate SQL schema matching backend expectations
  const sqlSchema = `CREATE TABLE IF NOT EXISTS ${tableName || "[nombre_tabla]"} (
  id_usuario VARCHAR(255),
  tipo_documento VARCHAR(50),
  numero_documento VARCHAR(255),
  fecha_inicio VARCHAR(50),
  fecha_fin VARCHAR(50),
  codigo VARCHAR(50)
);`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(sqlSchema);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const droppedFile = e.dataTransfer.files[0];
      if (droppedFile.name.endsWith(".csv") || droppedFile.name.endsWith(".txt") || droppedFile.name.endsWith(".tsv")) {
        setFile(droppedFile);
        setError(null);
      } else {
        setError("Tipo de archivo no válido. Selecciona un archivo CSV o TXT.");
      }
    }
  };

  // Robust fetch utility that retries on failed/HTML fallback responses
  const fetchWithRetry = async (url: string, options: RequestInit, maxRetries = 3, initialDelayMs = 1500): Promise<Response> => {
    let attempt = 0;
    while (true) {
      try {
        const response = await fetch(url, options);
        const contentType = response.headers.get("content-type");
        
        // If HTTP status is successful AND it is a JSON response, return it immediately
        if (response.ok && contentType && contentType.includes("application/json")) {
          return response;
        }

        // If status is ok but not JSON (like the HTML SPA fallback during server wakeup), wait and retry
        if (response.ok && (!contentType || !contentType.includes("application/json"))) {
          if (attempt < maxRetries) {
            attempt++;
            const delay = initialDelayMs * Math.pow(2, attempt - 1);
            console.warn(`[Retry ${attempt}/${maxRetries}] Recibida respuesta no-JSON (posible fallback HTML del servidor). Esperando ${delay}ms para reintentar...`);
            await new Promise((resolve) => setTimeout(resolve, delay));
            continue;
          }
        }

        // If we have some other error status, let's let caller handle or retry if appropriate
        if (!response.ok) {
          // Retry server error 502, 503, 504 and transient HTML responses
          if ((response.status >= 500 || !contentType || !contentType.includes("application/json")) && attempt < maxRetries) {
            attempt++;
            const delay = initialDelayMs * Math.pow(2, attempt - 1);
            console.warn(`[Retry ${attempt}/${maxRetries}] Error de red / respuesta inválida (${response.status}). Esperando ${delay}ms para reintentar...`);
            await new Promise((resolve) => setTimeout(resolve, delay));
            continue;
          }
        }

        return response;
      } catch (err) {
        if (attempt < maxRetries) {
          attempt++;
          const delay = initialDelayMs * Math.pow(2, attempt - 1);
          console.warn(`[Retry ${attempt}/${maxRetries}] Falló la conexión con el servidor. Esperando ${delay}ms para reintentar...`, err);
          await new Promise((resolve) => setTimeout(resolve, delay));
          continue;
        }
        throw err;
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setError(null);
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  // Upload file split in chunks
  const startMigration = async () => {
    if (!file) {
      setError("Por favor, selecciona un archivo CSV o TXT primero.");
      return;
    }
    if (!tableName.trim()) {
      setError("El nombre de la tabla de destino es un campo obligatorio.");
      return;
    }

    setError(null);
    setUploading(true);
    setClientProgress(0);
    setCurrentChunkIndex(0);
    setBackendStatus(null);
    setShowInvalidList(false);
    setShowFailedBatchesList(false);

    const CHUNK_SIZE = 5 * 1024 * 1024; // 5 MB chunks
    const generatedFileId = `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
    setFileId(generatedFileId);

    // Save state variables for persistent auto-reconnection recovery
    localStorage.setItem("migration_file_id", generatedFileId);
    localStorage.setItem("migration_table_name", tableName.trim());
    localStorage.setItem("migration_file_name", file.name);
    localStorage.setItem("migration_uploading", "true");

    const totalChunks = Math.ceil(file.size / CHUNK_SIZE);
    setTotalChunksIndex(totalChunks);

    try {
      for (let chunkIndex = 0; chunkIndex < totalChunks; chunkIndex++) {
        setCurrentChunkIndex(chunkIndex);
        setClientProgress(Math.floor((chunkIndex / totalChunks) * 100));

        const start = chunkIndex * CHUNK_SIZE;
        const end = Math.min(start + CHUNK_SIZE, file.size);
        const chunkBlob = file.slice(start, end);

        const formData = new FormData();
        formData.append("chunk", chunkBlob, file.name);
        formData.append("fileId", generatedFileId);
        formData.append("chunkIndex", String(chunkIndex));
        formData.append("totalChunks", String(totalChunks));
        formData.append("fileName", file.name);
        formData.append("tableName", tableName.trim());
        formData.append("delimiter", delimiter);
        formData.append("skipHeader", String(skipHeader));
        formData.append("supabaseUrl", supabaseUrl.trim());
        formData.append("supabaseKey", supabaseKey.trim());

        const response = await fetchWithRetry("/api/upload-chunk", {
          method: "POST",
          body: formData,
        });

        if (!response.ok) {
          let errorMessage = "Ocurrió un error al subir el fragmento (chunk) del archivo.";
          try {
            const errData = await response.json();
            if (errData && errData.error) {
              errorMessage = errData.error;
            }
          } catch {
            try {
              const textFallback = await response.text();
              if (textFallback) {
                errorMessage = textFallback.length > 120 
                  ? `${textFallback.slice(0, 117)}...` 
                  : textFallback;
              }
            } catch {}
          }
          throw new Error(errorMessage);
        }

        const data = await response.json();

        if (data && data.status === "processing") {
          break;
        }
      }

      // Hand over progress visualization to backend processing poll
      setStatusPollingActive(true);
    } catch (err: any) {
      console.error(err);
      setError(err?.message || "La transferencia de datos falló inesperadamente.");
      setUploading(false);
    }
  };

  // Poll backend database loading progress when active
  useEffect(() => {
    if (!statusPollingActive || !fileId) return;

    let isMounted = true;
    let consecutiveErrors = 0;

    const interval = setInterval(async () => {
      try {
        const response = await fetchWithRetry(`/api/migration-status/${fileId}`, { method: "GET" }, 2, 800);
        if (!response.ok) {
          throw new Error("No se pudo obtener el estado del servidor.");
        }
        const data = (await response.json()) as MigrationStatus;
        
        // Reset connection error count upon a successful status retrieval
        consecutiveErrors = 0;

        if (isMounted) {
          setBackendStatus(data);
          
          if (data.status === "completed") {
            setStatusPollingActive(false);
            setUploading(false);
            // Clear successfully completed state keys
            localStorage.removeItem("migration_file_id");
            localStorage.removeItem("migration_file_name");
            localStorage.removeItem("migration_uploading");
            clearInterval(interval);
          } else if (data.status === "failed") {
            setError(data.errorMessage || "Fallo en la carga masiva a la base de datos.");
            setStatusPollingActive(false);
            setUploading(false);
            localStorage.removeItem("migration_uploading");
            clearInterval(interval);
          }
        }
      } catch (err: any) {
        console.error("[Seguimiento de Conexión] Detectada anomalía temporal de red:", err);
        consecutiveErrors++;

        // Allow up to 15 consecutive polling errors (~18 seconds of server or websocket reconnect blankness)
        // This fully covers the scenario where a websocket closes, reboots, and reconnects
        if (consecutiveErrors > 15) {
          if (isMounted) {
            setError(err?.message || "Se perdió la conexión de seguimiento de manera permanente.");
            setStatusPollingActive(false);
            setUploading(false);
            clearInterval(interval);
          }
        } else {
          console.warn(`[Reconexión de Canal] No se pudo conectar con el servidor (${consecutiveErrors}/15). Manteniendo canal activo...`);
        }
      }
    }, 1200);

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [statusPollingActive, fileId]);

  const cancelAndReset = async () => {
    if (fileId) {
      try {
        await fetch(`/api/cancel-migration/${fileId}`, { method: "POST" });
      } catch (err) {
        console.warn("Cancel request failed", err);
      }
    }
    setFile(null);
    setUploading(false);
    setClientProgress(0);
    setCurrentChunkIndex(0);
    setTotalChunksIndex(0);
    setFileId("");
    setStatusPollingActive(false);
    setBackendStatus(null);
    setError(null);
    setShowInvalidList(false);
    setShowFailedBatchesList(false);
    
    // Clear persistent migration keys
    localStorage.removeItem("migration_file_id");
    localStorage.removeItem("migration_file_name");
    localStorage.removeItem("migration_uploading");
  };

  // Helper properties to map beautiful stages
  const getCurrentStage = () => {
    if (!uploading && !backendStatus) return "";
    if (backendStatus?.status === "completed") return "Migración Finalizada";
    if (backendStatus?.status === "failed") return "Error en la Migración";
    if (backendStatus?.status === "inserting") return "Insertando datos masivos en PostgreSQL...";
    if (backendStatus?.status === "merging") return "Uniendo fragmentos en el servidor...";
    if (clientProgress < 100 && !backendStatus) {
      return `Subiendo fragmentos (${currentChunkIndex + 1}/${totalChunksIndex})...`;
    }
    return "Procesando archivo...";
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col selection:bg-blue-600/20 selection:text-blue-800">
      
      {/* HEADER PRINCIPAL */}
      <header className="sticky top-0 z-50 bg-white/85 backdrop-blur-md border-b border-slate-200 px-6 py-4 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3">
          <div className="bg-blue-700 text-white p-2.5 rounded-xl shadow-md shadow-blue-700/20">
            <DatabaseZap className="h-6 w-6" id="header-logo-icon" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
              Supabase Bulk Migrator
            </h1>
            <p className="text-xs text-slate-500 font-medium">Migración híbrida optimizada para archivos de alto volumen</p>
          </div>
        </div>

        <div>
          <button
            onClick={startMigration}
            disabled={uploading || !file || !tableName.trim()}
            className={`cursor-pointer px-5 py-2.5 rounded-xl font-semibold text-sm flex items-center gap-2 shadow-sm transition-all duration-300 transform active:scale-95 ${
              uploading || !file || !tableName.trim()
                ? "bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200"
                : "bg-blue-700 text-white hover:bg-blue-800 hover:shadow-lg hover:shadow-blue-700/20"
            }`}
            id="insert-data-header-btn"
          >
            {uploading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                <span>Procesando...</span>
              </>
            ) : (
              <>
                <Play className="h-4 w-4 fill-current" />
                <span>Insertar Datos</span>
              </>
            )}
          </button>
        </div>
      </header>

      {/* CONTENIDO PRINCIPAL */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* COLUMNA IZQUIERDA: CONFIGURACIONES Y AYUDA SQL */}
        <div className="lg:col-span-5 flex flex-col gap-6" id="left-config-panel">
          
          {/* TARJETA CONFIGURACIONES */}
          <section className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-sm flex flex-col gap-5">
            <div className="flex items-center gap-2.5 pb-2 border-b border-slate-100">
              <span className="p-1.5 rounded-lg bg-blue-50 text-blue-700">
                <Database className="h-5 w-5" />
              </span>
              <h2 className="text-lg font-bold text-slate-800">1. Parámetros de la Base de Datos</h2>
            </div>

            {/* Input nombre de tabla */}
            <div className="flex flex-col gap-2">
              <label htmlFor="table-name-input" className="text-xs font-semibold uppercase tracking-wider text-slate-500 flex items-center justify-between">
                <span>Nombre de la Tabla PostgreSQL *</span>
                <span className="text-[10px] text-blue-600 font-medium">Requerido</span>
              </label>
              <div className="relative">
                <Database className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 h-4 w-4" />
                <input
                  id="table-name-input"
                  type="text"
                  required
                  disabled={uploading}
                  placeholder="Ej. registros_usuarios_historico"
                  value={tableName}
                  onChange={(e) => setTableName(e.target.value.replace(/[^a-zA-Z0-9_]/g, ""))}
                  className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-700/50 focus:border-blue-700 transition-all font-mono disabled:opacity-60 disabled:bg-slate-50"
                />
              </div>
              <p className="text-[11px] text-slate-400">Sólo caracteres alfanuméricos y guiones bajos (_) permitidos.</p>
            </div>

            {/* Configuraciones de delimitador y cabecera */}
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col gap-2">
                <label htmlFor="delimiter-select" className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                  Delimitador
                </label>
                <select
                  id="delimiter-select"
                  disabled={uploading}
                  value={delimiter}
                  onChange={(e) => setDelimiter(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-700/50 focus:border-blue-700 bg-white transition-all disabled:opacity-60 disabled:bg-slate-50"
                >
                  <option value=",">Comas ( , )</option>
                  <option value=";">Punto y coma ( ; )</option>
                  <option value="|">Pipe ( | )</option>
                  <option value="&#9;">Tabulaciones ( \t )</option>
                </select>
              </div>

              <div className="flex flex-col gap-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                  Fila de Cabecera
                </span>
                <button
                  type="button"
                  id="toggle-header-btn"
                  disabled={uploading}
                  onClick={() => setSkipHeader(!skipHeader)}
                  className={`flex-1 py-2.5 rounded-xl text-xs font-medium border transition-all cursor-pointer flex items-center justify-center gap-2 ${
                    skipHeader
                      ? "bg-blue-50 border-blue-200 text-blue-700 font-semibold"
                      : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                  }`}
                >
                  <FileSpreadsheet className="h-4 w-4" />
                  {skipHeader ? "Ignorar encabezado" : "Procesar todo"}
                </button>
              </div>
            </div>

            {/* Supabase Connection Settings Collapsible */}
            <div className="mt-2 border-t border-slate-100 pt-4">
              <button
                type="button"
                id="toggle-db-settings-btn"
                onClick={() => setShowDbSettings(!showDbSettings)}
                className="flex items-center justify-between w-full text-left text-xs font-bold uppercase tracking-wider text-slate-500 hover:text-slate-850 transition-colors py-1 cursor-pointer"
              >
                <span className="flex items-center gap-1.5">
                  <DatabaseZap className="h-3.5 w-3.5 text-blue-600" />
                  Conexión con Supabase personal
                </span>
                <span className="text-[11px] font-semibold text-blue-700">
                  {showDbSettings ? "Ocultar ▾" : "Personalizar ▸"}
                </span>
              </button>

              {showDbSettings && (
                <div className="mt-3 flex flex-col gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200/60" id="supabase-dynamic-creds-container">
                  {/* Supabase API URL */}
                  <div className="flex flex-col gap-1.5">
                    <label htmlFor="supabase-url-input" className="text-[11px] font-semibold text-slate-500">
                      Supabase Project URL
                    </label>
                    <input
                      id="supabase-url-input"
                      type="url"
                      disabled={uploading}
                      placeholder="https://your-project.supabase.co"
                      value={supabaseUrl}
                      onChange={(e) => setSupabaseUrl(e.target.value.trim())}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-xs font-mono focus:outline-none focus:ring-1 focus:ring-blue-700 focus:border-blue-700"
                    />
                  </div>

                  {/* Supabase Service Key / Anon Key */}
                  <div className="flex flex-col gap-1.5">
                    <label htmlFor="supabase-key-input" className="text-[11px] font-semibold text-slate-500 flex items-center justify-between">
                      <span>Supabase Service Key o Anon Key</span>
                      <span className="text-[10px] text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200/40">Recomendado Service Key</span>
                    </label>
                    <input
                      id="supabase-key-input"
                      type="password"
                      disabled={uploading}
                      placeholder="Su secreto o publicación anónima..."
                      value={supabaseKey}
                      onChange={(e) => setSupabaseKey(e.target.value.trim())}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-white text-xs font-mono focus:outline-none focus:ring-1 focus:ring-blue-700 focus:border-blue-700 font-semibold"
                    />
                    {supabaseKey && (
                      <div className="mt-1.5 flex flex-col gap-2">
                        {/* Anon Public Key Warning */}
                        {checkIsAnonKey(supabaseKey) && (
                          <div className="p-3 bg-amber-50 border border-amber-300 rounded-lg text-[11px] text-amber-850 font-medium flex flex-col gap-1.5 leading-normal shadow-sm">
                            <span className="font-bold text-amber-900 flex items-center gap-1">
                              ⚠️ ¡Clave Anon (Pública) Detectada!
                            </span>
                            <p className="text-slate-600">
                              Has copiado la clave con rol <strong>"anon"</strong> (es decir, el primer recuadro que dice <em>anon / public</em> en tu pantalla). Las claves públicas <strong>no se recomiendan para carga masiva directa</strong> desde nuestra app ya que suelen ser bloqueadas por las políticas Row Level Security (RLS) de su base de datos.
                            </p>
                            <p className="text-amber-950 font-bold">
                              💡 Solución: Sigue las instrucciones de la "Opción A" abajo para copiar la clave "service_role (secret)" que sí permite inserciones rápidas.
                            </p>
                          </div>
                        )}

                        {/* UUID Error (User is in JWT Keys section) */}
                        {/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(supabaseKey) && (
                          <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-[11px] text-rose-850 font-medium flex flex-col gap-1.5 leading-normal shadow-sm">
                            <span className="font-bold text-rose-900 flex items-center gap-1">
                              ❌ ¡ERROR: ID de Firma JWT Detectado!
                            </span>
                            <p className="text-slate-600">
                              Has copiado la clave desde la sección <strong>"JWT Keys"</strong> (ej. <code className="bg-slate-100 px-1 py-0.5 rounded text-xs font-mono">4D0A67C4-...</code>). Ese es un identificador de firma interno y <strong>no es una clave API de acceso</strong>.
                            </p>
                            <p className="text-slate-600 font-semibold">
                              Por favor, sigue los pasos de abajo para copiar la clave correcta.
                            </p>
                          </div>
                        )}

                        {/* Short Key or Truncated Key Warning */}
                        {!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(supabaseKey) && (supabaseKey.length < 35 || supabaseKey.includes("...") || (!supabaseKey.includes(".") && !supabaseKey.startsWith("sb_secret"))) && (
                          <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-[11px] text-amber-850 font-medium flex flex-col gap-1 leading-normal shadow-sm">
                            <span className="font-bold text-amber-900 flex items-center gap-1">
                              ⚠️ ¡Advertencia: Clave incompleta o incorrecta!
                            </span>
                            <p className="text-slate-600 text-[10.5px]">
                              La clave que ingresaste es corta o no tiene el formato esperado. Las claves de acceso de Supabase deben ser de uno de estos dos tipos:
                            </p>
                            <ul className="list-disc pl-4 text-slate-600 text-[10px] space-y-0.5">
                              <li>Un token JWT largo (empieza con <code className="bg-amber-100 px-1 rounded font-mono">eyJ...</code> y contiene puntos)</li>
                              <li>Una clave secreta nueva (empieza con <code className="bg-amber-100 px-1 rounded font-mono">sb_secret_...</code>)</li>
                            </ul>
                          </div>
                        )}

                        {/* Visual Help Guide based on User Screens */}
                        <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-lg text-[10.5px] text-blue-900 leading-normal shadow-sm">
                          <span className="font-bold text-blue-950 flex items-center gap-1 mb-1.5">
                            💡 Guía de Copiado (según tu pantalla actual):
                          </span>
                          
                          <div className="space-y-2 text-slate-700">
                            <div className="border-l-2 border-indigo-400 pl-2">
                              <p className="font-bold text-indigo-950">Opción A: pestaña "Legacy anon, service_role API keys"</p>
                              <ol className="list-decimal pl-4 mt-0.5 space-y-0.5 text-slate-600">
                                <li>Ubica la fila de <strong className="text-slate-800">service_role (secret)</strong>.</li>
                                <li>Haz clic en el botón <strong className="text-blue-700">"Reveal"</strong> en la derecha para mostrar los caracteres.</li>
                                <li>Selecciona y copia todo el texto revelado (suele comenzar con <code className="font-mono">eyJ...</code>). El <code className="font-mono">anon (public)</code> no sirve para escrituras RLS.</li>
                              </ol>
                            </div>

                            <div className="border-l-2 border-emerald-400 pl-2">
                              <p className="font-bold text-emerald-950">Opción B: pestaña "Publishable and secret API keys"</p>
                              <ol className="list-decimal pl-4 mt-0.5 space-y-0.5 text-slate-600">
                                <li>Baja hasta la sección <strong className="text-slate-800">"Secret keys"</strong>.</li>
                                <li>En la clave <strong className="text-slate-800">default</strong> (ej. <code className="font-mono">sb_secret_...</code>), haz clic en el <strong>icono de dos rectángulos (botón Copiar)</strong>.</li>
                                <li>Si está oculta en círculos, usa la opción de copiar directo. No copies el "Publishable key" de arriba.</li>
                              </ol>
                            </div>

                            <p className="text-rose-700 font-bold text-[10px] mt-1">
                              ❌ NO copies nada de la pestaña "JWT Keys", esas no son claves de API de base de datos.
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center justify-between border-t border-slate-200/60 pt-3">
                    <p className="text-[10px] text-slate-400 leading-normal max-w-[70%]">
                      Se usarán estas credenciales para la inserción masiva. Si se dejan las por defecto, se conectará al sandbox de pruebas.
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        setSupabaseUrl("https://bddexsjlwhwxhivcyfrk.supabase.co");
                        setSupabaseKey("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJkZGV4c2psd2h3eGhpdmN5ZnJrIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc4MDg0NDcwNiwiZXhwIjoyMDk2NDIwNzA2fQ.BfTFPxvapxxSqU7HRu5GGkjPoFZcQZSzqSUK9d1w-HQ");
                        setError(null);
                      }}
                      className="text-[10px] text-rose-600 hover:text-rose-750 font-bold uppercase tracking-wider py-1 px-2.5 hover:bg-rose-50 rounded-md transition-all cursor-pointer"
                    >
                      Restablecer
                    </button>
                  </div>
                </div>
              )}
            </div>
          </section>

          {/* TARJETA AYUDA SQL */}
          <section className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-sm flex flex-col gap-4">
            <div className="flex items-center justify-between pb-1">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-indigo-50 text-indigo-700">
                  <DatabaseZap className="h-4.5 w-4.5" />
                </span>
                <h3 className="font-bold text-slate-800 text-sm">Creación de Tabla en Supabase</h3>
              </div>
              <button
                type="button"
                id="copy-sql-btn"
                onClick={copyToClipboard}
                className="text-xs text-blue-700 font-semibold hover:text-blue-800 flex items-center gap-1 transition-all p-1 hover:bg-blue-50 rounded-lg cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="h-3.5 w-3.5 text-emerald-600" />
                    <span className="text-emerald-600">¡Copiado!</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-3.5 w-3.5" />
                    <span>Copiar SQL</span>
                  </>
                )}
              </button>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed">
              Para evitar errores, ejecute la siguiente sentencia en el Panel de Consultas SQL de su consola de Supabase antes de migrar:
            </p>

            <div className="relative py-3 px-4 rounded-xl bg-slate-950 text-slate-300 font-mono text-xs overflow-x-auto border border-slate-800 max-h-[170px] shadow-inner select-all">
              <pre>{sqlSchema}</pre>
            </div>

            <div className="flex gap-2 p-3 bg-amber-50 rounded-xl border border-amber-200/60 text-xs text-amber-800">
              <Info className="h-4 w-4 shrink-0 transition-transform hover:scale-110" />
              <p className="leading-normal">
                <strong>Estructura rígida:</strong> Su archivo TXT/CSV debe contener exactamente <strong>6 columnas</strong> que coincidan con este orden estructural para ser mapeado de forma masiva.
              </p>
            </div>
          </section>
        </div>

        {/* COLUMNA DERECHA: CARGADOR DE ARCHIVOS Y PANEL DE CONTROL */}
        <div className="lg:col-span-7 flex flex-col gap-6" id="right-uploader-panel">
          
          {/* FORM: INPUT UPLOADER */}
          <section className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-sm flex flex-col gap-5">
            <div className="flex items-center gap-2.5 pb-2 border-b border-slate-100">
              <span className="p-1.5 rounded-lg bg-blue-50 text-blue-700">
                <Upload className="h-5 w-5" />
              </span>
              <h2 className="text-lg font-bold text-slate-800">2. Cargador de Archivos Grandes</h2>
            </div>

            {/* Cuadro de arrastrar y soltar */}
            <div
              onDragEnter={handleDrag}
              onDragOver={handleDrag}
              onDragLeave={handleDrag}
              onDrop={handleDrop}
              onClick={() => !uploading && fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-all duration-300 relative overflow-hidden ${
                dragActive
                  ? "border-blue-700 bg-blue-50/50 ring-4 ring-blue-700/10"
                  : "border-slate-300 bg-slate-50/50 hover:border-blue-500 hover:bg-white"
              } ${uploading ? "opacity-50 cursor-not-allowed pointer-events-none" : ""}`}
              id="file-dropzone-uploader"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,.txt"
                onChange={handleFileChange}
                className="hidden"
                id="file-input-actual"
              />

              <div className="mb-4 bg-white shadow-md p-4 rounded-full text-blue-700 h-16 w-16 flex items-center justify-center relative">
                {uploading ? (
                  <Loader2 className="h-8 w-8 animate-spin text-blue-700" />
                ) : (
                  <Upload className="h-8 w-8 text-blue-700" />
                )}
              </div>

              {!file ? (
                <>
                  <p className="text-sm font-semibold text-slate-800">
                    Arrastra tu archivo aquí o haz clic para buscarlo
                  </p>
                  <p className="text-xs text-slate-400 mt-2">
                    Solo archivos .TXT o .CSV de cualquier tamaño (optimizado para +500 MB)
                  </p>
                </>
              ) : (
                <div className="flex flex-col items-center gap-1 w-full max-w-md">
                  <div className="flex items-center gap-2 bg-blue-50 border border-blue-200/50 py-1.5 px-3 rounded-full text-blue-800 text-xs font-semibold mb-2">
                    <FileText className="h-3.5 w-3.5" />
                    <span>{file.name.slice(-4).toUpperCase()} Detectado</span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-800 truncate max-w-full">
                    {file.name}
                  </h4>
                  <p className="text-xs text-slate-500 font-mono">
                    Tamaño: {formatBytes(file.size)}
                  </p>
                </div>
              )}
            </div>

            {/* Alertas de error */}
            <AnimatePresence mode="popLayout">
              {error && (
                <motion.div
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.25 }}
                  className="p-5 bg-rose-50 border border-rose-200 rounded-2xl flex flex-col gap-4 text-rose-800 text-sm shadow-sm"
                  id="error-alert"
                >
                  <div className="flex gap-3">
                    <AlertTriangle className="h-5 w-5 shrink-0 text-rose-600 mt-0.5 animate-bounce" />
                    <div>
                      <strong className="font-bold text-rose-900 block text-sm">Ocurrió un error en el proceso:</strong>
                      <span className="leading-relaxed font-semibold block mt-1 text-xs font-mono bg-rose-100/50 py-1 px-2.5 rounded border border-rose-200/30 overflow-x-auto max-w-full">
                        {error}
                      </span>
                    </div>
                  </div>

                  {(error.toLowerCase().includes("api key") || 
                    error.toLowerCase().includes("credentials") || 
                    error.toLowerCase().includes("supabase error")) && (
                    <div className="bg-white/80 p-4 rounded-xl border border-rose-100 text-slate-700 text-xs flex flex-col gap-3 shadow-inner">
                      <p className="font-bold text-rose-900 flex items-center gap-1.5 text-[13px]">
                        <Info className="h-4 w-4 text-indigo-600 shrink-0" />
                        Guía de Solución: Credenciales de Supabase
                      </p>
                      <p className="leading-relaxed text-slate-600 text-[11px]">
                        La conexión falló debido a una clave API no válida o expirada. Al eliminar o no configurar las variables de entorno, la aplicación intenta usar el sandbox de pruebas. 
                        Siga estos pasos sencillos para resolverlo:
                      </p>
                      <ol className="list-decimal pl-5 space-y-1.5 text-[11px] text-slate-600 font-medium">
                        <li>
                          Vaya a su consola de <strong className="text-blue-700">Supabase</strong>.
                        </li>
                        <li>
                          Ingrese a <strong className="text-slate-800">Project Settings ➔ API</strong>.
                        </li>
                        <li>
                          Copie la <strong className="text-slate-800">Project URL</strong> y el <strong className="text-slate-800">service_role key</strong> (esta última contiene los permisos para inserción masiva saltándose las políticas RLS si aplica).
                        </li>
                        <li>
                          Expanda la sección de abajo e inserte sus datos. Se guardarán de forma segura en local.
                        </li>
                      </ol>
                      
                      <button
                        type="button"
                        onClick={() => {
                          setShowDbSettings(true);
                          setTimeout(() => {
                            const container = document.getElementById("supabase-dynamic-creds-container");
                            if (container) {
                              container.scrollIntoView({ behavior: "smooth", block: "center" });
                              container.classList.add("ring-4", "ring-indigo-600/30", "transition-all");
                              setTimeout(() => {
                                container.classList.remove("ring-4", "ring-indigo-600/30");
                              }, 2000);
                            }
                          }, 100);
                        }}
                        className="mt-1 self-start px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 font-bold text-white uppercase tracking-wider text-[10px] rounded-lg transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
                      >
                        <DatabaseZap className="h-3.5 w-3.5" />
                        Configurar mi conexión de Supabase ahora
                      </button>
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Acción principal del botón */}
            <div className="flex gap-4 items-center">
              {uploading || backendStatus ? (
                <button
                  type="button"
                  id="cancel-migration-btn"
                  onClick={cancelAndReset}
                  className="cursor-pointer px-5 py-3 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 font-semibold text-sm transition-all"
                >
                  Cancelar / Reajustar
                </button>
              ) : null}

              <button
                type="button"
                id="start-mass-migration-btn"
                disabled={uploading || !file || !tableName.trim()}
                onClick={startMigration}
                className={`cursor-pointer flex-1 py-3.5 rounded-xl font-bold text-sm tracking-wide shadow-md transition-all flex items-center justify-center gap-2.5 active:scale-98 ${
                  uploading || !file || !tableName.trim()
                    ? "bg-slate-200 text-slate-400 cursor-not-allowed shadow-none"
                    : "bg-blue-700 text-white hover:bg-blue-800 hover:shadow-lg hover:shadow-blue-700/20"
                }`}
              >
                {uploading ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    <span>Migrando datos en segundo plano...</span>
                  </>
                ) : (
                  <>
                    <Play className="h-5 w-5 fill-current" />
                    <span>Iniciar Migración Masiva</span>
                  </>
                )}
              </button>
            </div>
          </section>

          {/* MONITOREO DE MIGRACIÓN (SÓLO CUANDO ES ACTIVO O COMPLETADO) */}
          <AnimatePresence>
            {(uploading || backendStatus) && (
              <motion.section
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                transition={{ type: "spring", stiffness: 300, damping: 25 }}
                className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-md flex flex-col gap-6"
                id="migration-monitoring-panel"
              >
                {/* Cabecera del monitoreo */}
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div>
                    <h3 className="font-bold text-slate-800 text-base flex items-center gap-2">
                      <RefreshCw className={`h-4.5 w-4.5 text-blue-700 ${backendStatus?.status !== "completed" && backendStatus?.status !== "failed" ? "animate-spin" : ""}`} />
                      <span>Monitoreo de Migración Activa</span>
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">Métricas de inserción en tiempo real desde la VPC de Supabase</p>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <span 
                      className="hidden md:inline-flex items-center gap-1 bg-gradient-to-r from-blue-50 to-indigo-50 text-blue-700 border border-blue-200 rounded-full px-2.5 py-1 text-[10px] font-bold select-none cursor-help shadow-3xs" 
                      title="¡Conexión tolerante! Si recargas la página o se interrumpe la red, el proceso continuará de forma segura en segundo plano y la pantalla se reconectará de inmediato mostrando el progreso (por ejemplo, el 50% actual) sin perder información."
                    >
                      <Zap className="h-3 w-3 animate-pulse text-blue-600 fill-current" />
                      Auto-Resiliente
                    </span>
                    <span className={`text-[11px] font-bold uppercase px-2.5 py-1 rounded-full ${
                      backendStatus?.status === "completed"
                        ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                        : backendStatus?.status === "failed"
                        ? "bg-rose-50 text-rose-700 border border-rose-200"
                        : "bg-blue-50 text-blue-700 border border-blue-200 animate-pulse"
                    }`}>
                      {backendStatus?.status === "completed" ? "ÉXITO" : backendStatus?.status === "failed" ? "FALLÓ" : "PROCESANDO"}
                    </span>
                  </div>
                </div>

                {/* Sub-título descriptivo de fase */}
                <div className="flex items-center gap-2.5 text-slate-700 text-sm font-semibold">
                  <span>Fase actual:</span>
                  <span className="text-blue-700 font-bold">{getCurrentStage()}</span>
                </div>

                {/* Barra de progreso */}
                <div className="flex flex-col gap-1.5">
                  <div className="relative h-3 w-full bg-slate-100 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: "0%" }}
                      animate={{ width: `${backendStatus ? backendStatus.progress : clientProgress}%` }}
                      className="absolute top-0 left-0 h-full bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-600 rounded-full transition-all duration-300"
                    />
                  </div>
                  <div className="flex justify-between items-center text-xs text-slate-500 font-semibold">
                    <span>Avance estimado</span>
                    <span className="font-mono text-slate-800 bg-slate-100 px-1.5 py-0.5 rounded text-[11px]">
                      {backendStatus ? backendStatus.progress : clientProgress}%
                    </span>
                  </div>
                </div>

                {/* Indicador de Lote en Tiempo Real */}
                {backendStatus?.currentBatchRange && (
                  <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3 flex justify-between items-center text-xs text-slate-600 font-medium shadow-3xs animate-fade-in">
                    <span className="flex items-center gap-2 text-slate-500">
                      <RefreshCw className="h-3.5 w-3.5 text-blue-600 animate-spin" />
                      Lote en Inserción Continua:
                    </span>
                    <span className="font-mono bg-blue-50 text-blue-800 px-2.5 py-1 rounded font-bold border border-blue-200/50 animate-pulse">
                      {backendStatus.currentBatchRange}
                    </span>
                  </div>
                )}

                {/* Métrica Bento Grid */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                  
                  <div className="bg-slate-50 border border-slate-100 p-3 rounded-xl flex flex-col gap-1">
                    <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">Filas Leídas</span>
                    <span className="text-base font-extrabold text-slate-800 font-mono">
                      {backendStatus?.totalRows.toLocaleString() || "0"}
                    </span>
                  </div>

                  <div className="bg-emerald-50/50 border border-emerald-100/60 p-3 rounded-xl flex flex-col gap-1">
                    <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-600">Insertadas Ok</span>
                    <span className="text-base font-extrabold text-emerald-800 font-mono">
                      {backendStatus?.insertedRows.toLocaleString() || "0"}
                    </span>
                  </div>

                  <div className={`p-3 rounded-xl border flex flex-col gap-1 transition-colors ${
                    (backendStatus?.invalidLinesCount || 0) > 0
                      ? "bg-amber-50 border-amber-200 text-amber-900"
                      : "bg-slate-50 border-slate-100 text-slate-850"
                  }`}>
                    <span className={`text-[10px] uppercase font-bold tracking-wider ${
                      (backendStatus?.invalidLinesCount || 0) > 0 ? "text-amber-700" : "text-slate-400"
                    }`}>
                      Formato Inválido
                    </span>
                    <span className={`text-base font-extrabold font-mono ${
                      (backendStatus?.invalidLinesCount || 0) > 0 ? "text-amber-800" : "text-slate-800"
                    }`}>
                      {backendStatus?.invalidLinesCount.toLocaleString() || "0"}
                    </span>
                  </div>

                  <div className={`p-3 rounded-xl border flex flex-col gap-1 transition-colors ${
                    (backendStatus?.failedBatchesCount || 0) > 0
                      ? "bg-rose-50 border-rose-200 text-rose-900"
                      : "bg-slate-50 border-slate-100 text-slate-850"
                  }`}>
                    <span className={`text-[10px] uppercase font-bold tracking-wider ${
                      (backendStatus?.failedBatchesCount || 0) > 0 ? "text-rose-700" : "text-slate-400"
                    }`}>
                      Lotes Fallidos (Supabase)
                    </span>
                    <span className={`text-base font-extrabold font-mono ${
                      (backendStatus?.failedBatchesCount || 0) > 0 ? "text-rose-800" : "text-slate-800"
                    }`}>
                      {backendStatus?.failedBatchesCount?.toLocaleString() || "0"}
                    </span>
                  </div>

                </div>

                {/* Desplegable Lista Inválidos */}
                {backendStatus && backendStatus.invalidLinesCount > 0 && (
                  <div className="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-sm flex flex-col">
                    <button
                      type="button"
                      onClick={() => setShowInvalidList(!showInvalidList)}
                      className="w-full flex items-center justify-between px-4 py-3 bg-slate-50 hover:bg-slate-100 transition-colors text-slate-700 font-bold text-xs uppercase tracking-wider select-none cursor-pointer"
                    >
                      <span className="flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4 text-amber-500 animate-pulse" />
                        <span>Lista Inválidos ({backendStatus.invalidLinesCount})</span>
                      </span>
                      <motion.span
                        animate={{ rotate: showInvalidList ? 90 : 0 }}
                        transition={{ duration: 0.15 }}
                        className="text-slate-400"
                      >
                        <ChevronRight className="h-4 w-4 text-slate-500" />
                      </motion.span>
                    </button>
                    
                    <AnimatePresence initial={false}>
                      {showInvalidList && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden border-t border-slate-200"
                        >
                          <div className="p-3 max-h-60 overflow-y-auto space-y-1.5 bg-slate-50/50">
                            {backendStatus.invalidLines && backendStatus.invalidLines.length > 0 ? (
                              backendStatus.invalidLines.map((item, idx) => (
                                <div key={idx} className="bg-white p-2.5 rounded-lg border border-slate-200 shadow-3xs flex gap-2 font-mono text-[11px] items-start">
                                  <span className="bg-amber-100 text-amber-900 px-1.5 py-0.5 rounded font-bold shrink-0">
                                    Línea {item.lineNum}
                                  </span>
                                  <span className="text-slate-600 break-all whitespace-pre-wrap select-text selection:bg-amber-200 selection:text-amber-900 leading-normal">
                                    {item.content}
                                  </span>
                                </div>
                              ))
                            ) : (
                              <div className="text-center py-4 text-xs text-slate-400 font-medium">
                                No hay registros inválidos cargados en memoria.
                              </div>
                            )}
                            
                            {backendStatus.invalidLinesCount > (backendStatus.invalidLines?.length || 0) && (
                              <p className="text-[10px] text-slate-400 italic text-center pt-1.5">
                                ... Mostrando los primeros {(backendStatus.invalidLines?.length || 0)} registros de estructura inválida ...
                              </p>
                            )}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )}

                {/* Desplegable Lista de Lotes Fallidos */}
                {backendStatus && (backendStatus.failedBatchesCount || 0) > 0 && (
                  <div className="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-sm flex flex-col mt-2">
                    <button
                      type="button"
                      onClick={() => setShowFailedBatchesList(!showFailedBatchesList)}
                      className="w-full flex items-center justify-between px-4 py-3 bg-red-50 hover:bg-rose-100 transition-colors text-red-700 font-bold text-xs uppercase tracking-wider select-none cursor-pointer"
                    >
                      <span className="flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4 text-red-500 animate-pulse" />
                        <span>Lotes Fallidos (Omitidos y Continuados) ({backendStatus.failedBatchesCount})</span>
                      </span>
                      <motion.span
                        animate={{ rotate: showFailedBatchesList ? 90 : 0 }}
                        transition={{ duration: 0.15 }}
                        className="text-red-400"
                      >
                        <ChevronRight className="h-4 w-4 text-red-500" />
                      </motion.span>
                    </button>
                    
                    <AnimatePresence initial={false}>
                      {showFailedBatchesList && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden border-t border-slate-200"
                        >
                          <div className="p-3 max-h-60 overflow-y-auto space-y-1.5 bg-red-50/25">
                            {backendStatus.failedBatches && backendStatus.failedBatches.length > 0 ? (
                              backendStatus.failedBatches.map((item, idx) => (
                                <div key={idx} className="bg-white p-2.5 rounded-lg border border-red-100 shadow-3xs flex flex-col gap-1 font-mono text-[11px]">
                                  <div className="flex justify-between items-center">
                                    <span className="bg-red-100 text-red-950 px-1.5 py-0.5 rounded font-bold shrink-0">
                                      {item.range}
                                    </span>
                                    <span className="text-red-600 font-sans text-[10px] font-semibold">Saltado</span>
                                  </div>
                                  <span className="text-slate-500 text-[10px] select-text selection:bg-red-200 leading-normal font-sans">
                                    Detalle del Error: {item.error}
                                  </span>
                                </div>
                              ))
                            ) : (
                              <div className="text-center py-4 text-xs text-slate-400 font-medium">
                                No hay información de errores disponible en memoria.
                              </div>
                            )}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )}

                {/* Información de éxito o fallas finales */}
                {backendStatus?.status === "completed" && (
                  <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex gap-3 text-emerald-950 text-sm">
                    <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <strong className="font-semibold text-emerald-900 block">Migración finalizada con éxito</strong>
                      <p className="leading-relaxed text-xs">
                        Se leyeron un total de {backendStatus.totalRows.toLocaleString()} registros. {backendStatus.insertedRows.toLocaleString()} filas se cargaron directamente en la tabla <strong>{backendStatus.tableName}</strong> de PostgreSQL. ¡Módulo de subida vacío y listo para otro archivo!
                      </p>
                    </div>
                  </div>
                )}
              </motion.section>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* FOOTER */}
      <footer className="bg-white border-t border-slate-200 px-6 py-4 mt-auto text-center text-xs text-slate-400">
        <p>© 2026 Supabase Bulk Migrator Engine. Optimizador de carga masiva híbrida. Todos los derechos reservados.</p>
      </footer>
    </div>
  );
}
