import { createClient, SupabaseClient } from "@supabase/supabase-js";

let clientInstance: SupabaseClient | null = null;

export function getSupabase(): SupabaseClient {
  if (!clientInstance) {
    const isBrowser = typeof window !== "undefined";
    
    let url = "";
    let key = "";
    
    if (isBrowser) {
      url = (import.meta as any).env?.VITE_SUPABASE_URL || "https://bddexsjlwhwxhivcyfrk.supabase.co";
      key = (import.meta as any).env?.VITE_SUPABASE_PUBLISHABLE_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJkZGV4c2psd2h3eGhpdmN5ZnJrIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc4MDg0NDcwNiwiZXhwIjoyMDk2NDIwNzA2fQ.BfTFPxvapxxSqU7HRu5GGkjPoFZcQZSzqSUK9d1w-HQ";
    } else {
      url = process.env.REACT_APP_SUPABASE_URL || "https://bddexsjlwhwxhivcyfrk.supabase.co";
      key = process.env.REACT_APP_SUPABASE_PUBLISHABLE_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJkZGV4c2psd2h3eGhpdmN5ZnJrIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc4MDg0NDcwNiwiZXhwIjoyMDk2NDIwNzA2fQ.BfTFPxvapxxSqU7HRu5GGkjPoFZcQZSzqSUK9d1w-HQ";
    }

    if (!url || url.trim() === "") {
      throw new Error("Supabase URL is required. Please check your environment configuration.");
    }
    if (!key || key.trim() === "") {
      throw new Error("Supabase Publishable Key is required. Please check your environment configuration.");
    }

    clientInstance = createClient(url, key);
  }
  return clientInstance;
}

// Transparent Proxy wrapper to enable lazy instantiation upon property access
export const supabase = new Proxy({}, {
  get(target, prop) {
    const client = getSupabase();
    const value = (client as any)[prop];
    if (typeof value === "function") {
      return value.bind(client);
    }
    return value;
  }
}) as any;

